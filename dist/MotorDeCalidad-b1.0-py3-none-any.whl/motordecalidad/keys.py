class AzureKeys:
    class Landing:
        Account = "fs.azure.account.key.adlseuedltb2b001.dfs.core.windows.net"
        Key = "JBBJSKUjq3q/EhpuIsBFGxCpI5M5/wvs4romw6eZBrH772HucQ2y9UKlfXIWpfYikjMn0wjE+Iki+ASt5AwC1Q=="
    class Solution:
        Account = "fs.azure.account.key.adlseuedltb2b002.dfs.core.windows.net"
        Key = "gLVky28N5XlvBnJEVZnLLxY1ZKCuUIzPta4kC04CDP2uek1UxLd0YQ11UDB1dNUswQgzA1Gjq6Z8+AStiSd7SQ=="
    class ObservedData:
        Account = "fs.azure.account.key.adlseuedltb2b001.blob.core.windows.net"
        Key = "JBBJSKUjq3q/EhpuIsBFGxCpI5M5/wvs4romw6eZBrH772HucQ2y9UKlfXIWpfYikjMn0wjE+Iki+ASt5AwC1Q=="