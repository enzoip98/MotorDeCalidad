##Constants
NullRuleCode = "101"
DuplicatedRuleCode = "102"
IntegrityRuleCode = "103"
InputSection = "INPUT"
RulesSection = "RULES"
Route = "ROUTE"
Header = "HEADER"
Delimiter = "DELIMITER"
Fields = "FIELDS"
KeyField = "KEY_FIELDS"
Country = "COUNTRY"
TestedRegisterAmount = "TEST_REGISTER_AMOUNT"
LeftAntiType = "leftanti"
One = 1
OutputDataFrameColumns = ["RULE_CODE","TEST_FIELD","SUCESS_RATE","FAILED_REGISTERS_AMOUNT"]